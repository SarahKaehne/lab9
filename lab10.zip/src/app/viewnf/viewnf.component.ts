import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewnf',
  templateUrl: './viewnf.component.html',
  styleUrls: ['./viewnf.component.css']
})
export class ViewnfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
